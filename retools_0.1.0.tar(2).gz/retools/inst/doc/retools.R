## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(retools)
library(ggplot2)

## -----------------------------------------------------------------------------
# Load sample dataset
data("pros_dataset")
pros.df <- pros_dataset

# Perform exploratory data analysis
ED_analysis(pros.df)

## -----------------------------------------------------------------------------
x <- c(1, 2, 3, 4, 5)
y <- c(2, 4, 5, 4, 5)
model1 <- lm_fit(x, y)


## -----------------------------------------------------------------------------
x <- c(1, 2, 3, 4, 5)
y <- c(2, 4, 5, 4, 5)
model1 <- lm_fit(x, y)
linear_regression(model1)


## -----------------------------------------------------------------------------
x <- c(1, 2, 3, 4, 5)
y <- c(2, 4, 5, 4, 5)
model1 <- lm_fit(x, y)
lm_coef_test(model1)


## -----------------------------------------------------------------------------
x <- c(1, 2, 3, 4, 5)
y <- c(2, 4, 5, 4, 5)
model1 <- lm_fit(x, y)
newdata1 <- data.frame(x1=c(6,7,8))
pred1 <- lm_predict(model1,newdata1)


## -----------------------------------------------------------------------------
# Set seed for reproducibility
set.seed(123)

# Create sample data
data <- data.frame(
  x1 = rnorm(100),
  x2 = rnorm(100),
  y = as.factor(sample(0:1, 100, replace = TRUE))
)

# Fit logistic regression model
coefficients <- logistic_regression(data, c("x1", "x2"), "y")
print(coefficients)

## -----------------------------------------------------------------------------
# Use the same seed 
set.seed(12)

# Create new data for prediction
newdata <- data.frame(
  x1 = rnorm(10),
  x2 = rnorm(10)
)

# Predict values using log_predict function
result <- log_predict(coefficients, newdata)
print(result)

## -----------------------------------------------------------------------------
# Assuming 'df' contains the dataset with 'hours' and 'score' variables
set.seed(1)
df <- data.frame(hours = runif(50, 5, 15), score=50)
df$score = df$score + df$hours^3/150 + df$hours*runif(50, 1, 2)
Polynomial_regression(df, K = 10, degree = 5)

## -----------------------------------------------------------------------------
set.seed(123)
  x <- seq(0, 10, length.out = 100)
  y <- sin(x) + rnorm(100, sd = 0.2)
  result1 <- loess_regression(x, y)
  head(result1, n = 1)

## -----------------------------------------------------------------------------
data <- set.seed(123)
  x <- seq(0, 10, length.out = 100)
  y <- sin(x) + rnorm(100, sd = 0.2)
  plot_loess(x, y, data)

## -----------------------------------------------------------------------------
set.seed(123)
  x <- seq(0, 10, length.out = 100)
  y <- sin(x) + rnorm(100, sd = 0.2)
  loess_model <- loess_regression(x, y, k = 5)

  new_x <- c(1, 2, 3, 4, 5)
  predictions <- predict_loess(new_x, loess_model)
  cat("predictions：", predictions, "\n")

## -----------------------------------------------------------------------------
set.seed(123)
  x <- c(2,4,6,4,6)
  y <- c(3,2,6,3,3)
  loess_model <- loess_regression(x, y, k = 5)
  result <- identify_outliers(x, y, loess_model, threshold = 0.2)
  head(result, n = 2)

