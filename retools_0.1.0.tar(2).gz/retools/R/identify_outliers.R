#' Identify outliers of the loess regression model data
#'
#' This function will use fitted loess regression model to identify outliers of data. This function accepts fitted loess regression model and threshold. It can help to identify the outliers in the dataset which used as loess regression model.
#'
#' @param x Numeric vector specifying the predictor variable.
#' @param y Numeric vector specifying the response variable.
#' @param loess_model The fitted loess regression model
#' @param threshold The threshold for identifying outliers
#'
#' @return A list of outliers, contain the fit point index, ovserved_value and its residuals.
#'
#' @examples
#' set.seed(123)
#' x <- seq(0, 10, length.out = 10)
#' y <- sin(x) + rnorm(10, sd = 0.2)
#' loess_model <- loess_regression(x, y, k = 5)
#' threshold <- 0.2
#' result1 <- identify_outliers(x, y, loess_model, threshold)
#'
#' @export
identify_outliers <- function(x, y, loess_model, threshold) {

  outliers <- list()
  for (i in seq_along(loess_model)) {
    observed_value <- vector()
    residuals_value <- vector()
    for (j in seq_along(loess_model[[i]]$residuals)){
      residuals <- loess_model[[i]]$residuals[[j]]
      if (abs(residuals) > threshold){
        cat("fit_point:",i,"observed_value:",j,"residuals:",loess_model[[i]]$residuals[[j]],"\n")
        outliers[[i]] <- list(
          fit_point <- i,
          observed_value <- c(observed_value, j),
          residuals_value <- c(residuals_value, residuals))
      }
    }
  }
  return(outliers)
}
