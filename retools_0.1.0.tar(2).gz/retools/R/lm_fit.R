#' Build a linear regression model.
#'
#' @param x A vector or a matrix, containing the explanatory variables.
#' @param y A vector, the response variable.
#'
#' @return A list object, containing the coefficients, fitted values, residuals, degrees of freedom and original data for the model.
#'
#' @examples
#' x <- c(1, 2, 3, 4, 5)
#' y <- c(2, 4, 5, 4, 5)
#' model1 <- lm_fit(x, y)
#'
#' @export
lm_fit <- function(x, y) {
  # 拟合线性回归模型
  mylist=list()
  x=as.matrix(x)
  x_new=cbind(rep(1,nrow(x)),x)
  coef=as.numeric(solve(t(x_new)%*%x_new)%*%(t(x_new)%*%y))
  names(coef)=c('(Intercept)',paste('x',1:ncol(x),sep=''))
  mylist[['coef']]=coef

  intercept=rep(1,nrow(x))
  x_full=cbind(intercept,x)
  y_fit=as.numeric(x_full %*% coef)
  resid=y-y_fit
  mylist[['fitted.values']]=y_fit
  mylist[['residuals']]=resid
  mylist[['df.residual']]=nrow(x)-ncol(x_new)
  data=data.frame(cbind(x,y))
  mylist[['data']]=data
  return(mylist)
}
