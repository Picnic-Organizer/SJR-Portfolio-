#' polynomial_regression
#'
#' This function performs polynomial regression on the provided dataset using
#' k-fold cross-validation to find the best model. It fits polynomial regression
#' models of varying degrees and selects the one with the lowest mean squared error (MSE).
#' It then visualizes the best polynomial regression model.
#'
#' @param data data
#' @param K The number of folds to use for k-fold cross-validation.
#' @param degree The maximum degree of polynomials to fit.
#'
#' @return prints the summary of the best model and visualizes it
#'
#' @import ggplot2
#'
#' @examples
#' # Assuming 'df' contains the dataset with 'hours' and 'score' variables
#' set.seed(1)
#' df <- data.frame(hours = runif(50, 5, 15), score=50)
#' df$score = df$score + df$hours^3/150 + df$hours*runif(50, 1, 2)
#' Polynomial_regression(df, K = 10, degree = 5)
#' @export
#' @name polynomial_regression
Polynomial_regression <- function(data, K, degree) {
  # Randomly shuffle data
  set.seed(1)
  df.shuffled <- data[sample(nrow(data)),]

  # Create k equal-sized folds for k-fold cross-validation
  folds <- cut(seq(1, nrow(df.shuffled)), breaks = K, labels = FALSE)

  # Create object to hold MSE's of models
  mse <- matrix(data = NA, nrow = K, ncol = degree)

  hours <- df.shuffled$hours
  score <- df.shuffled$score

  # Perform K-fold cross validation
  for(i in 1:K){
    # Define training and testing data
    testIndexes <- which(folds == i, arr.ind = TRUE)
    testData <- df.shuffled[testIndexes, ]
    trainData <- df.shuffled[-testIndexes, ]

    # Use k-fold cv to evaluate models
    for (j in 1:degree){
      fit.train <- lm(score ~ poly(hours, j), data = trainData)
      fit.test <- predict(fit.train, newdata = testData)
      mse[i, j] <- mean((fit.test - testData$score)^2)
    }
  }

  # Find MSE for each degree
  mse_means <- colMeans(mse)

  # Fit the best model
  best_degree <- which.min(mse_means)
  best_model <- lm(score ~ poly(hours, best_degree, raw = TRUE), data = data)
  coefficients <- coef(best_model)
  print(coefficients)
  # View summary of the best model
  print(summary(best_model))

  # Plot the best model
  plot1 <- ggplot(data, aes(x = hours, y = score)) +
    geom_point() +
    stat_smooth(method = 'lm', formula = y ~ poly(x, best_degree), linewidth = 1) +
    xlab('Hours Studied') +
    ylab('Score') +
    ggtitle('Polynomial Regression')
  return(plot1)
  return(coefficients)
}

