#' Predict the response for new observations.
#'
#' @param model The linear regression model built by using function lm_fit().
#' @param newdata A dataframe containing new observations.
#'
#' @return Predicted values
#'
#' @examples
#'
#' x <- c(1, 2, 3, 4, 5)
#' y <- c(2, 4, 5, 4, 5)
#' model1 <- lm_fit(x, y)
#' newdata1 <- data.frame(x1=c(6,7,8))
#' pred1 <- lm_predict(model1,newdata1)
#'
#' @export
lm_predict <- function(model,newdata){
  model=matrix(model[['coef']])
  intercept=rep(1,nrow(newdata))
  x_new_full=as.matrix(cbind(intercept,newdata))
  y_pred=as.numeric(x_new_full %*% model)
  names(y_pred)=rownames(newdata)
  return(y_pred)
}
