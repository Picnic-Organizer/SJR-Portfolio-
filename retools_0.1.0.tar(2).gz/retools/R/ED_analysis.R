#' Exploratory Data Analysis
#'
#' @param data A data frame containing the dataset.
#' @description This function performs exploratory data analysis on the provided dataset.
#'     It prints the dimensions of the dataset, displays the first few rows,
#'     plots histograms for each column, calculates the correlation matrix,
#'     prints highest correlation values, and visualizes the correlation matrix
#'     using a heatmap.
#'
#' @return None (prints exploratory data analysis results and visualizations)
#'
#' @importFrom grDevices cm.colors
#' @importFrom graphics hist par
#' @importFrom utils head

#'
#' @examples
#' test_data <- data.frame(A = c(1, 2, 3, 4, 5), B = c(6, 7, 8, 9, 10), C = c(11, 12, 13, 14, 15))
#' ED_analysis(test_data)
#' @export

ED_analysis <- function(data) {
  # Print dimensions of the data
  cat("The dimension is:\n")
  print(dim(data))

  # Print the first few rows of the data
  cat("The first few rows look like:\n")
  print(head(data))

  # Print column names
  cat("Column names:\n")
  print(colnames(data))

  # Setup grid for histograms
  par(mfrow=c(3,3), mar=c(4,4,2,0.5))

  # Create histograms for each column
  for (j in 1:ncol(data)) {
    hist(data[,j], xlab=colnames(data)[j],
         main=paste("Histogram of", colnames(data)[j]),
         col="lightblue", breaks=20)
  }

  # Calculate correlation matrix
  cor_matrix <- cor(data)
  cat("Correlation matrix:\n")
  print(round(cor_matrix, 3))

  # Remove lower triangle part of the correlation matrix
  cor_matrix[lower.tri(cor_matrix, diag=TRUE)] <- 0

  # Sort correlation matrix by absolute values
  cor_sorted <- sort(abs(cor_matrix), decreasing=TRUE)

  # Print highest correlation values and identify variables
  for (i in 1:length(cor_sorted)) {
    cor_value <- cor_sorted[i]
    if(cor_value != 0){
      vars_cor <- which(abs(cor_matrix) == cor_value, arr.ind = TRUE)
      var1 <- colnames(data)[vars_cor[1,1]]
      var2 <- colnames(data)[vars_cor[1,2]]
      cat("Correlation:", cor_value, "\n")
      cat("Variables:", var1, "and", var2, "\n\n")
    }
  }
  heatmap(cor_matrix,
          Rowv = NA, Colv = NA,
          col = cm.colors(256),
          scale = "none",
          margins = c(10,5))
}

