#' Logistic Regression
#'
#' Fits a logistic regression model to the data and visualizes the results using ggplot2.
#'
#' @param data A data frame containing the dataset.
#' @param x A character vector specifying the predictor variable(s).
#' @param y A character string specifying the response variable.
#'
#' @return displays summary of logistic regression model and the coefficients
#'
#' @import ggplot2
#'
#' @examples
#' set.seed(123)
#' data <- data.frame(
#'   x1 = rnorm(100),
#'   x2 = rnorm(100),
#'   y = as.factor(sample(0:1, 100, replace = TRUE))
#'  )
#'  coefficients <- logistic_regression(data, c("x1", "x2"), "y")
#'  print(coefficients)
#' @export
logistic_regression <- function(data, x, y) {
  # Check if the length of x is greater than 0
  if (length(x) == 0) {
    stop("At least one predictor variable (x) is required.")
  }

  # Create formula based on predictor variables
  form <- as.formula(paste(y, "~", paste(x, collapse = "+")))

  # Fit logistic regression model
  model <- glm(formula = form, data = data, family = "binomial")

  # Get summary of the model
  model_summary <- summary(model)

  # Extract coefficients from the model
  coefficients <- coef(model)

  # Return coefficients along with the summary
  return(list(summary = model_summary, coefficients = coefficients))
}

