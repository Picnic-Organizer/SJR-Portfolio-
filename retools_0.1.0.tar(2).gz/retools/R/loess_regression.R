#' Fit the loess regression model
#'
#' This function generates a loess regression model for the data. This function accepts the independent variable x, the dependent variable y, the number of K adjacent points of the k-fold cross-validation method, the value of the smoothness parameter span, and the degree used to calculate the weight, return a well-fitted loess regression model, including its fit point, the coefficient of moedl, the residual of each fit point and the weight.
#'
#' @param x independent value
#' @param y dependent value
#' @param k number of points closest to the fitting point
#' @param span Smoothness parameter
#' @param degree degree of the polynomial
#'
#' @return Returns a list with the following elements:
#' \enumerate{
#'   \item 'fit_point': The independent value of the fitting point
#'   \item 'coef': Coefficients of the fitted polynomial
#'   \item 'residuals': Residuals of the fitted values
#'   \item 'weights': Weights used for fitting
#' }
#'
#' @examples
#' df <- mtcars
#' print(head(df))
#' x <- mtcars$mpg
#' y <- mtcars$wt
#' loess_model <- loess_regression(x, y)
#' print(loess_model)
#'
#' @export

loess_regression <- function(x, y, k = 5, span = 0.75, degree = 1) {
  mylist <- list()
  n <- length(x)
  tricubic <- function(x) {
    y <- rep(0, length(x))
    idx <- (x >= -1) & (x <= 1)
    y[idx] <- (1 - abs(x[idx])^3)^3
    return(y)
  }
  for (i in 1:n) {
    distances <- abs(x - x[i])
    nearest_indices <- order(distances)[1:k]
    weights <- (1 - (distances[nearest_indices] / max(distances[nearest_indices])))^degree
    weights <- tricubic(weights) / sum(tricubic(weights))  # 使用三角权重
    X <- cbind(1, x[nearest_indices])  # Design matrix
    W <- diag(weights)  # Weight matrix
    coef <- solve(t(X) %*% W %*% X) %*% t(X) %*% W %*% y[nearest_indices]  # Coefficients
    fitted_values <- X %*% coef  # Fitted values
    residuals <- y[nearest_indices] - fitted_values  # Residuals

    mylist[[i]] <- list(
      fit_point = x[i],
      coef = coef,
      residuals = residuals,
      weights = weights
    )
  }

  return(mylist)
}

