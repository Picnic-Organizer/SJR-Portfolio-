#' Test whether the regression coefficients are significant.
#'
#' @param model The linear regression model built by using function lm_fit().
#'
#' @return The estimated value, standard error, t statistic and p-value for the linear regression coefficient.
#'
#' @examples
#' x <- c(1, 2, 3, 4, 5)
#' y <- c(2, 4, 5, 4, 5)
#' model1 <- lm_fit(x, y)
#' lm_coef_test(model1)
#'
#' @export
lm_coef_test <- function(model) {
  # 进行回归系数的假设检验
  X=model[['data']][,-ncol(model[['data']])]
  X=as.matrix(X)
  intercept=rep(1,nrow(X))
  x_full=as.matrix(cbind(intercept,X))
  colnames(x_full)=names(model[['coef']])
  Y=model[['data']][,ncol(model[['data']])]
  MSE=sum(model[['residuals']]^2)/model[['df.residual']]
  cov=solve(t(x_full) %*% x_full)*MSE

  test=matrix(0,nrow=ncol(x_full),ncol=4)
  rownames(test)=colnames(x_full)
  colnames(test)=c('Estimate','std error','t value','p value')
  for(i in 1:ncol(x_full)){
    test[i,1]=model[['coef']][i]
    test[i,2]=sqrt(cov[i,i])
    test[i,3]=test[i,1]/test[i,2]
    test[i,4]=pt(test[i,3],model[['df.residual']],lower.tail=F)*2
  }
  return(test)
}

