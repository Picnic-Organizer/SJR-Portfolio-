#' Logistic Regression Prediction
#'
#' This function predicts the response variable using a logistic regression model.
#'
#' @param coefficients A list containing the coefficients of the logistic regression model.
#' @param newdata A data frame containing new observations for prediction.
#' @return A vector of binary predictions.
#'
#' @examples
#' set.seed(123)
#' data <- data.frame(x1 = rnorm(100),x2 = rnorm(100),y = as.factor(sample(0:1, 100, replace = TRUE)))
#' coefficients <- logistic_regression(data, c("x1", "x2"), "y")
#' print(coefficients)
#' set.seed(123)
#' newdata <- data.frame(x1 = rnorm(10),x2 = rnorm(10))
#' result <- log_predict(coefficients, newdata)
#' print(result)
#'
#' @export
log_predict <- function(coefficients, newdata) {
  # Extract coefficients from the list if it's provided in that format
  if (is.list(coefficients)) {
    coefficients <- coefficients$coefficients
  }

  # Calculate linear predictor
  lin_pred <- as.matrix(newdata) %*% coefficients[-1] + coefficients[1]

  # Apply logistic transformation
  prob <- 1 / (1 + exp(-lin_pred))

  # Convert probabilities to binary predictions
  predictions <- ifelse(prob >= 0.5, 1, 0)

  return(predictions)
}
