#' Show the summary statistics, residuals and the fitted lines(if simple linear regression).
#'
#' @param model The linear regression model built by using function lm_fit().
#'
#' @return The summary statistics for the model, residuals and the regression plot(if simple linear regression).
#'
#' @import graphics
#'
#' @examples
#'
#' x <- c(1, 2, 3, 4, 5)
#' y <- c(2, 4, 5, 4, 5)
#' model1 <- lm_fit(x, y)
#' linear_regression(model1)
#'
#' @export
linear_regression=function(model){
  cat('Coefficients:','\n')
  print(lm_coef_test(model))
  RMSE=sqrt(sum(model[['residuals']]^2)/model[['df.residual']])
  cat('\n')
  cat('Residual standard error:',round(RMSE,4),'on',model[['df.residual']],
      'degrees of freedom')
  cat('\n')
  SSE=sum(model[['residuals']]^2)
  y=model[['data']][,ncol(model[['data']])]
  SST=sum((y-mean(y))^2)
  Rsq=1-SSE/SST

  X=model[['data']][,-ncol(model[['data']])]
  X=as.matrix(X)
  intercept=rep(1,nrow(X))
  x_full=as.matrix(cbind(intercept,X))

  adj_Rsq=1-(1-Rsq)*(nrow(x_full)-1)/(nrow(x_full)-ncol(x_full))
  cat('Multiple R-squared:',round(Rsq,4),'   ',
      'Adjusted R-squared:',round(adj_Rsq,4))
  F=((SST-SSE)/(ncol(x_full)-1))/((SSE)/(model[['df.residual']]))
  pval=pf(F,ncol(x_full)-1,model[['df.residual']],lower.tail=FALSE)
  cat('\n')
  cat('F-statistic:',F,'on',ncol(x_full)-1,'and',model[['df.residual']],
      'DF,','p-value:',round(pval,4))
  cat('\n')
  cat('\n')
  cat('Residuals:')
  cat('\n')
  print(model[['residuals']])

  if(ncol(model[['data']])==2){
    x=model[['data']][,1]
    y=model[['data']][,2]
    plot(x, y, main="Linear Regression", xlab="X", ylab="Y", pch=19)

    # 添加拟合线
    abline(a=model[['coef']][1],b=model[['coef']][2], col="red",lwd=1.5)
  }
}
