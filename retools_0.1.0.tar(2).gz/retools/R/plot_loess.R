#' Plot loess regression model curve
#'
#' This function imports ggplot2, plots a scatter plot using \code{geom_point()}, and saves it as an object \code{p}. Then, it adds a smoothed line using \code{geom_smooth()}.
#'
#' @param x The independent variable
#' @param y The dependent variable
#' @param data The data frame containing the variables
#'
#' @return A ggplot object of given loess regression model
#'
#' @examples
#' df <- mtcars
#' x <- mtcars$mpg
#' y <- mtcars$wt
#' plot_loess(x, y, df)
#'
#' @import ggplot2
#'
#' @export

plot_loess <- function(x, y, data) {
  p <- ggplot() + geom_point(data, mapping = aes(x, y)) + theme_bw()
  p <- p + geom_smooth(data, mapping = aes(x, y), method = "loess")
  return(p)
}

