#'Predict new points based on fitted loess model.
#'
#'This function predicts the dependent variable of the new data point from the fitted loess regression model. This function predicts each new dependent variable by using the weighted average of the fitting points of the adjacent loess model.
#'
#' @param new_x The argument value of the new data point
#' @param loess_model The fitted loess regression model
#'
#' @return Return a vector with each predict dependent variable
#'
#' @examples
#' set.seed(123)
#' x <- seq(0, 10, length.out = 10)
#' y <- sin(x) + rnorm(10, sd = 0.2)
#' loess_model <- loess_regression(x, y)
#' new_x <- seq(1, 10, length.out = 30)
#' predict_loess(new_x, loess_model)
#'
#' @import stats
#'
#' @export
# Predict the response variable values of the new data points according to the loess model

predict_loess <- function(new_x, loess_model) {
  final_prediction <- vector()
  predictions <- numeric(length(new_x))
  fit_points <- list()
  for (i in 1:length(loess_model)) {
    fit_points[[i]] <- loess_model[[i]]$fit_point
  }
  for (i in seq_along(new_x)) {
    nearest_index <- which.min(abs(as.numeric(fit_points) - new_x[i]))
    print(nearest_index)
    fit_point_info <- loess_model[[nearest_index]]
    coef <- fit_point_info$coef
    weights <- fit_point_info$weights

    X <- cbind(1, new_x[i])
    predicted_value <- X %*% coef
    predicted_value <- as.vector(predicted_value)

    final_prediction <- c(final_prediction, sum(predicted_value * weights))
  }
  return(final_prediction)
}
