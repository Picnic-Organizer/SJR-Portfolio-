test_that("Polynomial_regression function produces expected output", {
  # Set the seed
  set.seed(123)

  # Generate a dataset
  n <- 100
  hours <- runif(n, 0, 10)
  score <- 2 * hours^2 - 3 * hours + rnorm(n, 0, 2)
  data <- data.frame(hours, score)

  # Call the Polynomial_regression function
  result <- capture.output(Polynomial_regression(data, K = 5, degree = 3))

  # Check if result is a ggplot object
  expect_type(result, "character")
  expect_true("Coefficients:" %in% result)

})
