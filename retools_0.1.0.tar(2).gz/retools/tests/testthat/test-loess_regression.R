test_that("Testing loess_regression with simulated data", {
  set.seed(123)
  x <- seq(0, 10, length.out = 10)
  y <- sin(x) + rnorm(10, sd = 0.2)
  loess_model <- loess_regression(x, y)

  expect_equal(length(loess_model), 10)
  expect_equal(length(loess_model[[1]]$fit_point), 1)
  expect_equal(length(loess_model[[1]]$coef), 2)
  expect_equal(length(loess_model[[1]]$residuals), 5)
  expect_equal(length(loess_model[[1]]$weights), 5)

})
