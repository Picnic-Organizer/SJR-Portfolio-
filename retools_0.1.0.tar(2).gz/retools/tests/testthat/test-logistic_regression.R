test_that("logistic_regression function produces expected output", {
  # Set seed for reproducibility
  set.seed(123)

  # Create sample data
  data <- data.frame(
    x1 = rnorm(100),
    x2 = rnorm(100),
    y = as.factor(sample(0:1, 100, replace = TRUE))
  )

  # Fit logistic regression model
  coefficients <- logistic_regression(data, c("x1", "x2"), "y")

  # Check if coefficients are returned
  expect_true("coefficients" %in% names(coefficients))

  # Check if summary of the model is returned
  expect_true("summary" %in% names(coefficients))
})
