test_that("identify_outliers works correctly",{
  #Test case 1:
  set.seed(123)
  x <- seq(0, 10, length.out = 10)
  y <- sin(x) + rnorm(10, sd = 0.2)
  loess_model <- loess_regression(x, y, k = 5)
  threshold <- 0.2
  result1 <- identify_outliers(x, y, loess_model, threshold)

  for (i in 1 : length(result1)){
    expect_equal(length(result1[[i]][[2]]), length(result1[[i]][[3]])) #This judge that whether
    for (j in 1 : length(result1[[i]][[3]])){
      expect_true(abs(result1[[i]][[3]][[j]]) > threshold)
    }
  }

})
