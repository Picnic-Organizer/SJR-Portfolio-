test_that("lm_coef_test function produces the expected output structure", {
  # Generate a test model
  x <- c(1, 2, 3, 4, 5)
  y <- c(2, 4, 5, 4, 5)
  model <- lm_fit(x, y)

  # Run lm_coef_test on the test model
  result <- lm_coef_test(model)

  # Check if the result is a matrix
  expect_type(result, "double")

  # Check if the matrix column names are correct
  expect_equal(colnames(result), c("Estimate", "std error", "t value", "p value"), info = "Column names should be 'Estimate', 'std error', 't value', 'p value'")
})

