test_that("ED_analysis function produces expected output", {
  test_data <- data.frame(
    A = c(1, 2, 3, 4, 5),
    B = c(6, 7, 8, 9, 10),
    C = c(11, 12, 13, 14, 15)
  )
  capture_output <- capture.output(ED_analysis(test_data))
  expect_true("The dimension is:" %in% capture_output)
  expect_true("The first few rows look like:" %in% capture_output)
  expect_true("Column names:" %in% capture_output)
  expect_true("Correlation matrix:" %in% capture_output)
})
