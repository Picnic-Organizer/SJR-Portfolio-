test_that("lm_fit function produces the expected output structure", {
  # Test case: simple linear regression
  x <- c(1, 2, 3, 4, 5)
  y <- c(2, 4, 5, 4, 5)
  model1 <- lm_fit(x, y)

  # Check if the result is a list
  expect_type(model1, "list")

  # Check if the list contains required elements
  expect_true("coef" %in% names(model1), info = "List should contain 'coef'")
  expect_true("fitted.values" %in% names(model1), info = "List should contain 'fitted.values'")
  expect_true("residuals" %in% names(model1), info = "List should contain 'residuals'")
  expect_true("df.residual" %in% names(model1), info = "List should contain 'df.residual'")
  expect_true("data" %in% names(model1), info = "List should contain 'data'")
})
