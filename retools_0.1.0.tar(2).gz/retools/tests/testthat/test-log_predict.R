test_that("log_predict function produces expected output", {
  # Set seed for reproducibility
  set.seed(123)

  # Create sample data
  data <- data.frame(
    x1 = rnorm(100),
    x2 = rnorm(100),
    y = as.factor(sample(0:1, 100, replace = TRUE))
  )

  # Fit logistic regression model
  coefficients <- logistic_regression(data, c("x1", "x2"), "y")

  # Create new data for prediction
  newdata <- data.frame(
    x1 = rnorm(10),
    x2 = rnorm(10)
  )

  # Predict values using log_predict function
  result <- log_predict(coefficients, newdata)

  # Check if result is a vector
  expect_type(result, "double")

  # Check if length of result is equal to the number of rows in newdata
  expect_equal(length(result), nrow(newdata))
})
