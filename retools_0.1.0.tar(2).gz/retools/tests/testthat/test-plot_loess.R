test_that("plot_loess works correctly",{
  #Test case 1:
  data <- set.seed(123)
  x <- seq(0, 10, length.out = 100)
  y <- sin(x) + rnorm(100, sd = 0.2)
  result1 <- plot_loess(x, y, data)

  #Test case 2:
  data <- mtcars
  head(mtcars)
  x <- mtcars$mpg
  y <- mtcars$wt
  result2 <- plot_loess(x, y, data)

  expect_type(result1, "list")
  expect_type(result2, "list")

})
