test_that("predict_loess works correctly",{
  #Test case 1
  set.seed(123)
  x <- seq(0, 10, length.out = 100)
  y <- sin(x) + rnorm(100, sd = 0.2)
  loess_model <- loess_regression(x, y, k = 5)

  new_x <- c(1, 2, 3, 4, 5)
  predictions <- predict_loess(new_x, loess_model)
  cat("predictions：", predictions, "\n")

  expect_equal(length(predictions), 5)
  expect_true(is.double(predictions))
}
)
