test_that("lm_predict works correctly", {
  # Test case 1: simple linear regression
  x <- c(1, 2, 3, 4, 5)
  y <- c(2, 4, 5, 4, 5)

  model1 <- lm_fit(x, y)
  newdata1 <- data.frame(x1 = c(6, 7, 8))
  pred1 <- lm_predict(model1, newdata1)

  # Check the predictions for test case 1
  expect_equal(length(pred1), length(newdata1[[1]]))

  # Test case 2: multiple linear regression
  x <- matrix(c(1, 2, 3, 4, 5, 1, 4, 5, 6, 5), nrow = 5)
  y <- c(2, 4, 5, 4, 5)

  model2 <- lm_fit(x, y)
  newdata2 <- data.frame(x1 = c(6, 7, 8), x2 = c(1, 2, 3))
  pred2 <- lm_predict(model2, newdata2)

  # Check the predictions for test case 2
  expect_equal(length(pred2), length(newdata2[[1]]))
})
