class Node:
    def __init__(self, element, pointer):
        self.element = element
        self.pointer = pointer

class SinglyLinkedList:
    def __init__(self):
        self.head = None
        self.size = 0

    def insert(self, data):
        self.head = Node(data, self.head)


    def recursive_count(self, node):

        if node is None:
           return self.size
        else:
            self.size = self.size+1
            return self.recursive_count(node.pointer)

test1 = SinglyLinkedList()
for i in range(4):
    test1.insert(i)
print(test1.recursive_count(test1.head))
