class Node:
    def __init__(self, element, pointer):
        self.element = element
        self.pointer = pointer

class SinglyLinkedList:
    def __init__(self):
        self.head = None
        self.tail = None
        self.size = 0

    def insert(self, data):
        self.head = Node(data, self.head)

    def quick_sort(self, node):
        self.recursive_sort(test11.head, test11.tail)
        return test11.head

    def recursive_sort(self, start, end):
        if (self.recursive_count(self.head) == 0) or (start is end):
            return
        try:
            x = start
            y = x.pointer
            while y is not None:
                if y.element < start.element:
                    x = x.pointer
                    temp = y.element
                    y.element = x.element
                    x.element = temp
                y = y.pointer
            temp = start.element
            start.element = x.element
            x.element = temp
            self.recursive_quick_sort(start, x)
            self.recursive_quick_sort(x.pointer, end)
        except:
            return

    def recursive_count(self, node):
        if node != self.tail:
            return 1 + test11.recursive_count(node.pointer)
        else:
            return 1





test11 = SinglyLinkedList()
nums = [4, 3, 2, 1, 0, -1]
len_nums = len(nums)
for i in range(len_nums):
    test11.insert(nums[i])

test11.quick_sort(test11.head)

node_test = test11.head
print(node_test.element)

while node_test.pointer != None:
    i = i + 1
    node_test = node_test.pointer
    print(node_test.element)
