def HanoiTower(n):
    ListTower = [0] * n
    if n % 2 == 0:
        Tower = ['A', 'B', 'C']
    elif n % 2 != 0:
        Tower = ['A', 'C', 'B']

    for i in range(1, 2 ** n):
        j = bin(i)
        n = len(j) - j.rfind('1') - 1

        print(Tower[ListTower[n]], end='-->')
        if n % 2 == 0:
            ListTower[n] = (ListTower[n] + 1) % 3
        elif n % 2 != 0:
            ListTower[n] = (ListTower[n] + 2) % 3
        print(Tower[ListTower[n]])
        

HanoiTower(3)
